import 'package:boxicons/boxicons.dart';
import 'package:flutter/material.dart';
import 'package:sena/Screens/Carrito_Screen/productos.dart';
import '../../constants.dart';
import 'package:url_launcher/url_launcher.dart';

class Cart extends StatefulWidget {
  final List<ProductosModel> _cart;

  const Cart(this._cart, {super.key});

  @override
  State<Cart> createState() => _CartState(_cart);
}

class _CartState extends State<Cart> {
  _CartState(this._cart);

  final _scrollController = ScrollController();
  var _firstScroll = true;
  final bool _enabled = false;
  final List<ProductosModel> _cart;

  Container pagoTotal(List<ProductosModel> cart) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: kPrimaryColor,
        boxShadow: [
          BoxShadow(
              color: kPrimaryColor.withOpacity(0.45),
              offset: Offset(0, 10),
              blurRadius: 20),
        ],
      ),
      alignment: Alignment.centerRight,
      padding: const EdgeInsets.only(left: 120),
      height: 50,
      width: 400,
      child: Row(
        children: [
          Text(
            "TOTAL: \$${valorTotal(cart)}",
            style: const TextStyle(
                fontWeight: FontWeight.bold, fontSize: 20, color: Colors.white),
          )
        ],
      ),
    );
  }

  String valorTotal(List<ProductosModel> listaProductos) {
    double total = 0.0;
    for (int i = 0; i < listaProductos.length; i++) {
      total = total + listaProductos[i].price * listaProductos[i].quantity;
    }
    return total.toStringAsFixed(2);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: kPrimaryColor,
      ),
      body: GestureDetector(
        onVerticalDragUpdate: (details) {
          if (_enabled && _firstScroll) {
            _scrollController
                .jumpTo(_scrollController.position.pixels - details.delta.dy);
          }
        },
        onVerticalDragEnd: (_) {
          if (_enabled) _firstScroll = false;
        },
        child: SingleChildScrollView(
          child: Column(
            children: [
              ListView.builder(
                scrollDirection: Axis.vertical,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: _cart.length,
                itemBuilder: (context, index) {
                  final String image = _cart[index].image;
                  var item = _cart[index];
                  return Column(children: [
                    Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: kDefaultPadding,
                          vertical: 2.0,
                        ),
                        child: Column(
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  child: SizedBox(
                                    width: 100,
                                    height: 100,
                                    child: Image.asset("img/$image",
                                        fit: BoxFit.contain),
                                  ),
                                ),
                                Column(
                                  children: [
                                    Text(
                                      item.name,
                                      style: const TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 16,
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(
                                        top: kDefaultPadding,
                                      ),
                                      child: Text(
                                        item.price.toString(),
                                        style: const TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(
                                      left: kDefaultPadding * 2),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          const SizedBox(
                                            height: 8.0,
                                          ),
                                          IconButton(
                                            icon: const Icon(Icons
                                                .do_not_disturb_on_outlined),
                                            onPressed: () {
                                              _removeProduct(index);
                                              valorTotal(_cart);
                                            },
                                          ),
                                          Text(
                                            "${_cart[index].quantity}",
                                            style: const TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 22.0,
                                            ),
                                          ),
                                          IconButton(
                                            icon: const Icon(
                                                Boxicons.bx_plus_circle),
                                            onPressed: () {
                                              _addProduct(index);
                                              valorTotal(_cart);
                                            },
                                          ),
                                          const SizedBox(
                                            height: 8.0,
                                          )
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            )
                          ],
                        )),
                    const Divider(
                      color: Colors.grey,
                    )
                  ]);
                },
              ),
              pagoTotal(_cart),
              Padding(
                padding: const EdgeInsets.only(
                  top: kDefaultPadding * 2,
                  bottom: kDefaultPadding,
                ),
                child: SizedBox(
                  width: 200,
                  height: 50,
                  child: ElevatedButton(
                    style: ButtonStyle(
                      shape: MaterialStateProperty.all(
                        RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                      ),
                    ),
                    onPressed: () {
                      showDialog(
                          context: context,
                          builder: (context) => SimpleDialog(
                                title: const Text("ACEPTA PAGAR LA COMPRA"),
                                contentPadding: const EdgeInsets.all(20.0),
                                children: [
                                  const Text(
                                      "Esta seguro de comprar estos productos"),
                                  TextButton(
                                    onPressed: () {
                                      msgListaPedido();
                                    },
                                    child: const Text("Comprar"),
                                  ),
                                  TextButton(
                                    onPressed: () {
                                      Navigator.of(context).pop();
                                    },
                                    child: const Text("Close"),
                                  )
                                ],
                              ));
                    },
                    child: const Text("COMPRAR"),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
      bottomNavigationBar: Container(
        height: 80,
        decoration: const BoxDecoration(
          color: kPrimaryColor,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(40),
            topRight: Radius.circular(40),
          ),
        ),
      ),
    );
  }

  _addProduct(int index) {
    setState(() {
      _cart[index].quantity++;
    });
  }

  _removeProduct(int index) {
    setState(() {
      _cart[index].quantity--;
    });
  }

  void msgListaPedido() async {
    String pedido = "";
    String fecha = DateTime.now().toString();
    pedido = "${pedido}FECHA:$fecha";
    pedido = "$pedido\n";
    pedido = "${pedido}MEGA DESCUENTOS A DOMICILIO";
    pedido = "$pedido\n";
    pedido = "${pedido}CLIENTE: FLUTTER - DART";
    pedido = "$pedido\n";
    pedido = "${pedido}_____________";
    pedido = "${pedido}Puedes pasar por tu pedido en tres dias habiles";

    for (int i = 0; i < _cart.length; i++) {
      pedido = '$pedido' "\n" "Producto : " +
          _cart[i].name +
          "\n" +
          "Cantidad: " +
          _cart[i].quantity.toString() +
          "\n" +
          "Precio : " +
          _cart[i].price.toString() +
          "\n" +
          "_________________________\n";
    }
    pedido = "${pedido}TOTAL:${valorTotal(_cart)}";

    // ignore: deprecated_member_use
    await launch("https://wa.me/${573245504803}?text=$pedido");
  }
}
