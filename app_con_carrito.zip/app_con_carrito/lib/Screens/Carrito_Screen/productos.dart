import 'package:flutter/material.dart';

class ProductosModel {
  final String name;
  final String image;
  final int price;
  final VoidCallback press;
  int quantity;

  ProductosModel(
      {required this.name,
      required this.press,
      required this.image,
      required this.price,
      this.quantity = 1});
}
