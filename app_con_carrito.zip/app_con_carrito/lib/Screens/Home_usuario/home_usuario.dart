import 'package:boxicons/boxicons.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_nav_bar/google_nav_bar.dart';
import 'package:sena/constants.dart';

import '../Carrito_Screen/pedido.dart';
import '../Carrito_Screen/productos.dart';
import '../User_Screen/user_screen.dart';

class HomeUser extends StatefulWidget {
  const HomeUser({super.key});

  @override
  State<HomeUser> createState() => _HomeUserState();
}

class _HomeUserState extends State<HomeUser> {
  List<ProductosModel> _productosModel = <ProductosModel>[];

  final List<ProductosModel> _listaCarro = <ProductosModel>[];

  @override
  void initState() {
    super.initState();
    _productosDb();
    _categorias();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: [
          Padding(
            padding:
                const EdgeInsets.only(right: kDefaultPadding * 18, top: 8.0),
            child: GestureDetector(
              child: Stack(
                alignment: Alignment.topRight,
                children: [
                  const Icon(
                    Icons.receipt_long,
                    size: 38,
                  ),
                  if (_listaCarro.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(left: 2.0),
                      child: CircleAvatar(
                        radius: 8.0,
                        backgroundColor: Colors.red,
                        foregroundColor: Colors.white,
                        child: Text(
                          _listaCarro.length.toString(),
                          style: const TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 12.0),
                        ),
                      ),
                    ),
                ],
              ),
              onTap: () {
                if (_listaCarro.isNotEmpty) {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => Cart(_listaCarro),
                    ),
                  );
                }
              },
            ),
          )
        ],
      ),
      body: _cuadroProductos(),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: kDefaultPadding - 5,
          vertical: kDefaultPadding - 10,
        ),
        child: GNav(
          backgroundColor: kBackgroundColor,
          activeColor: kBackgroundColor,
          tabBackgroundColor: kPrimaryColor,
          gap: 10,
          padding: const EdgeInsets.all(kDefaultPadding - 7),
          tabMargin:
              const EdgeInsets.symmetric(horizontal: kDefaultPadding * 2),
          tabs: [
            GButton(
              onPressed: () {
                Navigator.of(context).push(
                  CupertinoPageRoute(
                    builder: (context) => const HomeUser(),
                  ),
                );
              },
              icon: Icons.home,
              text: "Inicio",
            ),
            GButton(
              onPressed: () {
                Navigator.of(context).push(
                  CupertinoPageRoute(
                    builder: (context) => const UserPage(),
                  ),
                );
              },
              icon: Icons.person,
              text: "Usuario",
            ),
          ],
        ),
      ),
    );
  }

  _cuadroProductos() {
    return ListView.builder(
      padding: const EdgeInsets.all(4.0),
      itemCount: _productosModel.length,
      itemBuilder: (context, index) {
        final String image = _productosModel[index].image;
        var item = _productosModel[index];

        return Column(
          children: [
            Container(
              margin: const EdgeInsets.symmetric(
                horizontal: kDefaultPadding * 3,
                vertical: kDefaultPadding,
              ),
              child: Column(
                children: <Widget>[
                  GestureDetector(
                    onTap: item.press,
                    child: Image.asset("img/$image"),
                  ),
                  Container(
                    padding: const EdgeInsets.all(kDefaultPadding / 2),
                    decoration: BoxDecoration(
                      borderRadius: const BorderRadius.only(
                        bottomLeft: Radius.circular(10),
                        bottomRight: Radius.circular(10),
                      ),
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                          offset: const Offset(0, 10),
                          blurRadius: 50,
                          color: kPrimaryColor.withOpacity(0.23),
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        Container(
                          child: RichText(
                            text: TextSpan(
                              children: [
                                TextSpan(
                                  text: item.name.toUpperCase(),
                                  style: Theme.of(context).textTheme.button,
                                ),
                              ],
                            ),
                          ),
                        ),
                        const Spacer(),
                        Text(
                          item.price.toString(),
                          style: Theme.of(context)
                              .textTheme
                              .button
                              ?.copyWith(color: kPrimaryColor, fontSize: 20),
                        ),
                        Padding(
                          padding: EdgeInsets.only(left: kDefaultPadding * 2),
                          child: GestureDetector(
                            child: (!_listaCarro.contains(item))
                                ? const Icon(
                                    Icons.receipt_long,
                                    color: Colors.black,
                                    size: 38,
                                  )
                                : const Icon(
                                    Icons.receipt_long,
                                    color: kPrimaryColor,
                                    size: 38,
                                  ),
                            onTap: () {
                              setState(() {
                                if (!_listaCarro.contains(item)) {
                                  _listaCarro.add(item);
                                } else {
                                  _listaCarro.remove(item);
                                }
                              });
                            },
                          ),
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ),
          ],
        );
      },
    );
  }

  void _categorias() {
    var list = <ProductosModel>[
      ProductosModel(
        name: "Acelgas",
        image: "Acelgas.jpg",
        price: 2500,
        press: () {
          acelgasModal(context);
        },
      ),
      ProductosModel(
        name: "Aguacate",
        image: "Aguacate.jpg",
        price: 5000,
        press: () {
          aguacateModal(context);
        },
      ),
      ProductosModel(
        name: "Arequipe",
        image: "Arequipe.jpg",
        price: 5000,
        press: () {
          arequipeModal(context);
        },
      ),
      ProductosModel(
        name: "Brocoli",
        image: "Brocoli.jpg",
        price: 2300,
        press: () {
          brocoliModal(context);
        },
      ),
      ProductosModel(
        name: "Crema de leche",
        image: "Crema_de_leche.jpg",
        price: 5600,
        press: () {
          cremadelecheModal(context);
        },
      ),
      ProductosModel(
        name: "Cuajada",
        image: "Cuajada.jpg",
        price: 3450,
        press: () {
          cuajadaModal(context);
        },
      ),
      ProductosModel(
        name: "Granadilla",
        image: "Granadilla.jpg",
        price: 2500,
        press: () {
          granadillaModal(context);
        },
      ),
      ProductosModel(
        name: "Huevos codorniz",
        image: "Huevos_codorniz.jpg",
        price: 6000,
        press: () {
          huevosdecodornizModal(context);
        },
      ),
      ProductosModel(
        name: "Huevos A",
        image: "Huevos_gallina.jpg",
        price: 11000,
        press: () {
          huevosAModal(context);
        },
      ),
      ProductosModel(
        name: "Huevos AA",
        image: "Huevos_gallina.jpg",
        price: 12000,
        press: () {
          huevosAAModal(context);
        },
      ),
      ProductosModel(
        name: "Huevos AAA",
        image: "Huevos_gallina.jpg",
        price: 13000,
        press: () {
          huevosAAAModal(context);
        },
      ),
      ProductosModel(
        name: "Huevos Jumbo",
        image: "Huevos_gallina.jpg",
        price: 14000,
        press: () {
          huevosjumboModal(context);
        },
      ),
      ProductosModel(
        name: "Leche cabra",
        image: "Leche_cabra.jpg",
        price: 12000,
        press: () {
          lecheDeCabraModal(context);
        },
      ),
      ProductosModel(
        name: "Leche vaca",
        image: "Leche_vaca.jpg",
        price: 3000,
        press: () {
          lechedevacaModal(context);
        },
      ),
      ProductosModel(
        name: "Lechuga",
        image: "Lechuga.jpg",
        price: 5000,
        press: () {
          lechugaModal(context);
        },
      ),
      ProductosModel(
        name: "Mantequilla",
        image: "Mantequilla.jpg",
        price: 3000,
        press: () {},
      ),
      ProductosModel(
        name: "Maracuya",
        image: "Maracuya.jpg",
        price: 3450,
        press: () {
          maracuyaModal(context);
        },
      ),
      ProductosModel(
        name: "Miel",
        image: "Miel.jpg",
        price: 18000,
        press: () {
          mielModal(context);
        },
      ),
      ProductosModel(
        name: "Mora",
        image: "Mora.jpg",
        price: 4000,
        press: () {
          moraModal(context);
        },
      ),
      ProductosModel(
        name: "Pollo",
        image: "Pollo.jpg",
        price: 30000,
        press: () {
          polloModal(context);
        },
      ),
      ProductosModel(
        name: "Queso",
        image: "Queso.jpg",
        price: 4000,
        press: () {
          quesoModal(context);
        },
      ),
      ProductosModel(
        name: "Suculentas",
        image: "Suculentas.jpg",
        price: 5000,
        press: () {
          suculentasModal(context);
        },
      ),
      ProductosModel(
        name: "Tomate",
        image: "Tomate.jpg",
        price: 4000,
        press: () {
          tomateModal(context);
        },
      ),
      ProductosModel(
        name: "Yogurt de mora",
        image: "Yogurt_de_mora.jpg",
        price: 1500,
        press: () {
          yogurtdemoraModal(context);
        },
      ),
      ProductosModel(
        name: "Yogurt griego",
        image: "Yogurt_griego.jpg",
        price: 6000,
        press: () {
          yogurtModal(context);
        },
      ),
      ProductosModel(
        name: "Zanahorias",
        image: "Zanahorias.jpg",
        price: 3000,
        press: () {
          zanahoriaModal(context);
        },
      ),
    ];

    setState(() {
      _productosModel = list;
    });
  }

  void _productosDb() {
    var list = <ProductosModel>[
      ProductosModel(
        name: "Acelgas",
        image: "Acelgas.jpg",
        price: 2500,
        press: () {
          acelgasModal(context);
        },
      ),
      ProductosModel(
        name: "Aguacate",
        image: "Aguacate.jpg",
        price: 5000,
        press: () {
          aguacateModal(context);
        },
      ),
      ProductosModel(
        name: "Arequipe",
        image: "Arequipe.jpg",
        price: 5000,
        press: () {
          arequipeModal(context);
        },
      ),
      ProductosModel(
        name: "Brocoli",
        image: "Brocoli.jpg",
        price: 2300,
        press: () {
          brocoliModal(context);
        },
      ),
      ProductosModel(
        name: "Crema de leche",
        image: "Crema_de_leche.jpg",
        price: 5600,
        press: () {
          cremadelecheModal(context);
        },
      ),
      ProductosModel(
        name: "Cuajada",
        image: "Cuajada.jpg",
        price: 3450,
        press: () {
          cuajadaModal(context);
        },
      ),
      ProductosModel(
        name: "Granadilla",
        image: "Granadilla.jpg",
        price: 2500,
        press: () {
          granadillaModal(context);
        },
      ),
      ProductosModel(
        name: "Huevos codorniz",
        image: "Huevos_codorniz.jpg",
        price: 6000,
        press: () {
          huevosdecodornizModal(context);
        },
      ),
      ProductosModel(
        name: "Huevos A",
        image: "Huevos_gallina.jpg",
        price: 11000,
        press: () {
          huevosAModal(context);
        },
      ),
      ProductosModel(
        name: "Huevos AA",
        image: "Huevos_gallina.jpg",
        price: 12000,
        press: () {
          huevosAAModal(context);
        },
      ),
      ProductosModel(
        name: "Huevos AAA",
        image: "Huevos_gallina.jpg",
        price: 13000,
        press: () {
          huevosAAAModal(context);
        },
      ),
      ProductosModel(
        name: "Huevos Jumbo",
        image: "Huevos_gallina.jpg",
        price: 14000,
        press: () {
          huevosjumboModal(context);
        },
      ),
      ProductosModel(
        name: "Leche cabra",
        image: "Leche_cabra.jpg",
        price: 12000,
        press: () {
          lecheDeCabraModal(context);
        },
      ),
      ProductosModel(
        name: "Leche vaca",
        image: "Leche_vaca.jpg",
        price: 3000,
        press: () {},
      ),
      ProductosModel(
        name: "Lechuga",
        image: "Lechuga.jpg",
        price: 5000,
        press: () {
          lechugaModal(context);
        },
      ),
      ProductosModel(
        name: "Mantequilla",
        image: "Mantequilla.jpg",
        price: 2500,
        press: () {
          mantequillaModal(context);
        },
      ),
      ProductosModel(
        name: "Maracuya",
        image: "Maracuya.jpg",
        price: 3450,
        press: () {
          maracuyaModal(context);
        },
      ),
      ProductosModel(
        name: "Miel",
        image: "Miel.jpg",
        price: 18000,
        press: () {
          mielModal(context);
        },
      ),
      ProductosModel(
        name: "Mora",
        image: "Mora.jpg",
        price: 4000,
        press: () {
          moraModal(context);
        },
      ),
      ProductosModel(
        name: "Pollo",
        image: "Pollo.jpg",
        price: 30000,
        press: () {
          polloModal(context);
        },
      ),
      ProductosModel(
        name: "Queso",
        image: "Queso.jpg",
        price: 4000,
        press: () {
          quesoModal(context);
        },
      ),
      ProductosModel(
        name: "Suculentas",
        image: "Suculentas.jpg",
        price: 5000,
        press: () {
          suculentasModal(context);
        },
      ),
      ProductosModel(
        name: "Tomate",
        image: "Tomate.jpg",
        price: 4000,
        press: () {
          tomateModal(context);
        },
      ),
      ProductosModel(
        name: "Yogurt de mora",
        image: "Yogurt_de_mora.jpg",
        price: 1500,
        press: () {
          yogurtdemoraModal(context);
        },
      ),
      ProductosModel(
        name: "Yogurt griego",
        image: "Yogurt_griego.jpg",
        price: 6000,
        press: () {
          yogurtModal(context);
        },
      ),
      ProductosModel(
        name: "Zanahorias",
        image: "Zanahorias.jpg",
        price: 3000,
        press: () {
          zanahoriaModal(context);
        },
      ),
    ];

    setState(() {
      _productosModel = list;
    });
  }
}

huevosAAModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 250,
            minHeight: 220,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Huevos Tamaño AA",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "Huevos de granja feliz cosechados por nuestros aprendices siento estos una fuente de proteina y calcio muy importante, se vende por cubeta",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

mielModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 250,
            minHeight: 200,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Miel",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "Miel cosechada y tratada por nuestros aprencides, la miel se comercializa en un frasco de vidirio como en la foto, pesando este 32 Gramos",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

tomateModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 270,
            minHeight: 200,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Tomate",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "Tomate cosechado por nuestros aprendices, este siendo una de las verduras más conocidas, se venden en un paquete de plasticos con 6 unidades cada paca",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

moraModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 250,
            minHeight: 200,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Mora",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "La mora es un excelente producto para acompañarlo en el almuerzo en forma de bebida, se vende en bolsas con la libra deseada",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

lecheDeCabraModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 250,
            minHeight: 200,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Leche de Cabra",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "La leche de cabra es una fuente muy grande de calcio, esta fue cosechada por nuestros aprendices, se vende por litro en una botella de vidrio",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

destacados1Modal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 200,
            minHeight: 200,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Tomate",
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 20,
                            color: kBackgroundColor),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(
                          Boxicons.bx_x_circle,
                          color: kBackgroundColor,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "El tomate en este periodo tuvo un aumento del 40% en las ventas siendo esto algo nuevo en nuestra comercializadora",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

destacados2Modal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 200,
            minHeight: 200,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Lechuga",
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 20,
                            color: kBackgroundColor),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(
                          Boxicons.bx_x_circle,
                          color: kBackgroundColor,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "La lechuga fue un producto que tuvo su boom por el aumento de demanda de este, siendo un 70% más demandado que otro producto en nuestra comercializadora",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

acelgasModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 260,
            minHeight: 220,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Acelgas",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "Las acelgas destacan por su altísimo valor nutricional y por ser unos vegetales que aportan un contenido calórico muy bajo a tu dieta, se vende por atao ",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

aguacateModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 250,
            minHeight: 220,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Aguacate",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "El aguacate Mejora la digestión. Nutre la piel, las uñas y el cabello por su alto contenido en vitaminas C y E, se vende en un paquete de 5 aguacates",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

brocoliModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 266,
            minHeight: 220,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Brócoli",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "El brócoli posee una mayor riqueza en vitaminas y minerales respecto al resto de las crucíferas. Se destaca su contenido en vitamina A, vitamina C, ácido fólico, potasio y hierro, Se vende por libra un paquete",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

granadillaModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 234,
            minHeight: 220,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Granadilla",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "La granadilla te puede ayudar a prevenir el estreñimiento, los malestares de la gastritis y la acidez, se vende por libras la granadilla",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

lechugaModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 250,
            minHeight: 220,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Lechuga",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "Los beneficios principales que te aporta la lechuga son: Es un alimento remineralizante, alcalinizante y refrescante, la lechuga se vende por ramo cada uno",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

maracuyaModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 218,
            minHeight: 218,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Maracuyá",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "La maracuyá es un fruto con gran aporte de vitamina C, potasio y calcio, esta se vende por paquetes de 1 libra",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

suculentasModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 266,
            minHeight: 220,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Suculentas",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "Las plantas suculentas o crasas son aquellas en las que algún órgano está especializado en el almacenamiento de agua en cantidades mayores que las plantas sin esta adaptación, esta se vende por unidad",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

zanahoriaModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 266,
            minHeight: 220,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Zanahoria",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "La Zanahoria Es rica en fósforo, el cual vigoriza las mentes y cuerpos cansados. Es muy útil para eliminar los cólicos y favorece la digestión, esta se vende en paquetes de 1 libra",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

arequipeModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 266,
            minHeight: 220,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Arequipe",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "El arequipe es un producto lácteo, producido por la cocción de leche con azúcar y que generalmente se utiliza como cobertura de postres o para untar o jaspear, se vende por frascos de 30gr",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

cremadelecheModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 250,
            minHeight: 220,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Crema de Leche",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "La crema, nata o gordura de leche es una sustancia de consistencia grasa y color marfil que se encuentra de forma emulsionada en la leche recién ordeñada o cruda, se vende por gramaje",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

cuajadaModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 320,
            minHeight: 320,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Cuajada",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "La Cuajada no se trata de un queso como tal, sino de leche coagulada sin fermentar con cuajo animal o bien extracto de cardo. Podemos encontrar dos variedades diferentes, la Cuajada que se elabora sin apenas nata ni suero, conocida como Cuajada natural, o la obtenida por coagulación, se vende por libra",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

lechedevacaModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 266,
            minHeight: 266,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Leche de vaca",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "La leche de vaca cruda es un líquido de color blanco amarillento que ha adquirido gran importancia en la alimentación humana. Al hablar de leche se entiende única y exclusivamente la natural de vaca, se vende por litro",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

lecheritaModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 300,
            minHeight: 300,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Leche condensada",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "La leche condensada se obtiene eliminando parte del agua que contiene la leche de partida y añadiendo azúcar. También se somete a un tratamiento térmico, con el fin de garantizar la estabilidad del alimento a temperatura ambiente, mientras el envase esté cerrado, se vende por gramaje",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

mantequillaModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 282,
            minHeight: 282,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Mantequilla",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "La mantequilla es un derivado lácteo con un elevado contenido graso, derivado exclusivamente de la leche o de determinados productos lácteos, en forma de emulsión sólida principalmente del tipo agua en materia grasa, se vende por libra cuarto y medias",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

quesoModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 300,
            minHeight: 300,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Queso",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "El queso es un alimento elaborado a partir de la leche cuajada de vaca, cabra, oveja u otros mamíferos. Sus diferentes estilos y sabores son el resultado del uso de distintas especies de bacterias y mohos, niveles de nata en la leche, curación, tratamientos en su proceso, etc, se vende por libra",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

yogurtdemoraModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 320,
            minHeight: 320,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Yogurt de Mora",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "Es un producto lácteo obtenido mediante la fermentación de la leche3 por medio de bacterias de los géneros Lactobacillus y Streptococcus. Se suelen usar varias cepas diferentes para conseguir una fermentación más completa, existen varios sabores de yogurt, pero el más producido es el de mora, se vende por mililitros y litros",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

yogurtModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 290,
            minHeight: 290,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Yogurt Griego",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "El yogur griego, también llamado labne, es el yogur que se cola para retirar el suero de leche, generando en una textura mucho más espesa y cremosa que la del yogur natural, manteniendo ese amargor característico y sumándole notas cítricas, se vende por gramaje",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

huevosdecodornizModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 320,
            minHeight: 320,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Huevos de Codorniz",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "Más pequeños que los de gallina y con una yema más viva, los huevos de codorniz son una auténtica exquisitez que destaca por su alto contenido en proteínas y la casi inexistencia de carbohidratos. De hecho, su aporte energético es superior a los primeros pese a sus dimensiones inferiores, se vende por cubeta x 6",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

huevosAModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 250,
            minHeight: 220,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Huevos Tamaño A",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "Huevos de granja feliz cosechados por nuestros aprendices siento estos una fuente de proteina y calcio muy importante, se vende por cubeta",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

huevosAAAModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 250,
            minHeight: 220,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Huevos Tamaño AAA",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "Huevos de granja feliz cosechados por nuestros aprendices siento estos una fuente de proteina y calcio muy importante, se vende por cubeta",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

huevosjumboModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 250,
            minHeight: 220,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Huevos Tamaño Jumbo",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "Huevos de granja feliz cosechados por nuestros aprendices siento estos una fuente de proteina y calcio muy importante, se vende por cubeta",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

polloModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 285,
            minHeight: 285,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Pollo",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "La carne de pollo está considerada como un alimento básico en la dieta humana. Su bajo costo de producción en comparación a otras carnes hace que sea consumida en casi todo el mundo y por todas las clases sociales, se vende por unidad",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}
