import 'package:flutter/material.dart';

const double kDefaultPadding = 20.0;
const kPrimaryColor = Color(0xFF01AF01);
const kBackgroundColor = Color(0xFFF9f8FD);
