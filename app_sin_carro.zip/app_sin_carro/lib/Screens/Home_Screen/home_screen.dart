import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_nav_bar/google_nav_bar.dart';
import 'package:sena/Screens/Home_Screen/body_home_screen.dart';
import 'package:sena/constants.dart';

import '../MainPage_Screen/pagemaincreate.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: buildAppBar(),
      body: const BodyHomeScreen(),
      bottomNavigationBar: buildNavBar(context),
    );
  }

  Padding buildNavBar(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: kDefaultPadding - 5,
        vertical: kDefaultPadding - 10,
      ),
      child: GNav(
        backgroundColor: kBackgroundColor,
        activeColor: kBackgroundColor,
        tabBackgroundColor: kPrimaryColor,
        gap: 10,
        padding: const EdgeInsets.all(kDefaultPadding - 7),
        tabs: [
          GButton(
            onPressed: () {
              Navigator.of(context).push(
                CupertinoPageRoute(
                  builder: (context) => const HomeScreen(),
                ),
              );
            },
            icon: Icons.home,
            text: "Inicio",
          ),
          GButton(
            onPressed: () {},
            icon: Icons.receipt_long,
            text: "Lista",
          ),
          GButton(
            onPressed: () {
              Navigator.of(context).push(
                CupertinoPageRoute(
                  builder: (context) => const MainPage(),
                ),
              );
            },
            icon: Icons.person,
            text: "Usuario",
          ),
        ],
      ),
    );
  }

  AppBar buildAppBar() {
    return AppBar(
      elevation: 0,
      leading: IconButton(
        icon: const Icon(Icons.receipt_long_outlined),
        onPressed: () {},
      ),
    );
  }
}
