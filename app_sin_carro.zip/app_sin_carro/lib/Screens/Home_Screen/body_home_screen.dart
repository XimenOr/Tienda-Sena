import 'package:boxicons/boxicons.dart';
import 'package:flutter/material.dart';
import 'package:sena/constants.dart';

class BodyHomeScreen extends StatefulWidget {
  const BodyHomeScreen({super.key});

  @override
  State<BodyHomeScreen> createState() => _BodyHomeScreenState();
}

class _BodyHomeScreenState extends State<BodyHomeScreen> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return SingleChildScrollView(
      child: Column(
        children: <Widget>[
          HeaderWithSearchBox(size: size),
          TitleWithSeeMore(
              text: 'Categorias',
              press: () {
                categoriasModal(context);
              }),
          const CategoriesProducts(),
          TitleWithSeeMore(
              text: 'Recomendado',
              press: () {
                recomendadoModal(context);
              }),
          const RecomendProducts(),
          TitleWithSeeMore(
            text: 'Destacados',
            press: () {
              destacadosModal(context);
            },
          ),
          const FeaturedProducts(),
          TitleWithSeeMore(
            text: 'Agricola',
            press: () {
              agricolaModal(context);
            },
          ),
          const AgricolaProducts(),
          TitleWithSeeMore(
            text: 'Lacteos',
            press: () {
              lacteosModal(context);
            },
          ),
          const DairyProducts(),
          TitleWithSeeMore(
            text: 'Producots Animales',
            press: () {
              productoAnimalModal(context);
            },
          ),
          const AnimalProducts(),
        ],
      ),
    );
  }
}

class CategoriesProducts extends StatelessWidget {
  const CategoriesProducts({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          Categories(
            img: "img/Agricola.jpg",
            text: 'Agricola',
            press: () {},
          ),
          Categories(
            img: "img/Lacteos.jpg",
            text: 'Lacteos',
            press: () {},
          ),
          Categories(
            img: "img/Derivado_animal.jpg",
            text: 'Producto Animal',
            press: () {},
          ),
        ],
      ),
    );
  }
}

class Categories extends StatelessWidget {
  const Categories({
    Key? key,
    required this.img,
    required this.text,
    required this.press,
  }) : super(key: key);
  final String img, text;
  final VoidCallback press;

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Container(
      margin: const EdgeInsets.only(
        left: kDefaultPadding,
        top: kDefaultPadding / 2,
        bottom: kDefaultPadding * 2.5,
      ),
      width: size.width * 0.4,
      child: GestureDetector(
        onTap: () {},
        child: Column(
          children: <Widget>[
            ClipRRect(
              borderRadius: BorderRadius.circular(300),
              child: Image(
                width: 125,
                height: 125,
                image: AssetImage(img),
              ),
            ),
            Container(
              padding: const EdgeInsets.all(kDefaultPadding / 2),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Text(
                    text,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 17,
                    ),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}

class AnimalProducts extends StatelessWidget {
  const AnimalProducts({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: <Widget>[
          Card(
            img: "img/Huevos_codorniz.jpg",
            title: "Huevos",
            about: "Codorniz x 12",
            price: 6400,
            press: () {
              huevosdecodornizModal(context);
            },
          ),
          Card(
            img: "img/Huevos_gallina.jpg",
            title: "Huevos",
            about: "Tipo A X 30",
            price: 11000,
            press: () {
              huevosAModal(context);
            },
          ),
          Card(
            img: "img/Huevos_gallina.jpg",
            title: "Huevos",
            about: "Tipo AA X 30",
            price: 12000,
            press: () {
              huevosAAModal(context);
            },
          ),
          Card(
            img: "img/Huevos_gallina.jpg",
            title: "Huevos",
            about: "tipo AAA X 30",
            price: 13000,
            press: () {
              huevosAAAModal(context);
            },
          ),
          Card(
            img: "img/Huevos_gallina.jpg",
            title: "Huevos",
            about: "Jumbo X 30",
            price: 14000,
            press: () {
              huevosjumboModal(context);
            },
          ),
          Card(
            img: "img/Leche_cabra.jpg",
            title: "Leche Cabra",
            about: "1 Litro",
            price: 10000,
            press: () {
              lecheDeCabralModal(context);
            },
          ),
          Card(
            img: "img/Leche_vaca.jpg",
            title: "Leche Vaca",
            about: "1 Litro",
            price: 3000,
            press: () {
              lechedevacaModal(context);
            },
          ),
          Card(
            img: "img/Miel.jpg",
            title: "Miel",
            about: "32Gr x 1",
            price: 18000,
            press: () {
              mielModal(context);
            },
          ),
          Card(
            img: "img/Pollo.jpg",
            title: "Pollo",
            about: "1 Unidad",
            price: 18000,
            press: () {
              polloModal(context);
            },
          ),
          Card(
            img: "img/Yogurt_griego.jpg",
            title: "Yogurt",
            about: "40 Gr",
            price: 8000,
            press: () {
              yogurtModal(context);
            },
          ),
        ],
      ),
    );
  }
}

class DairyProducts extends StatelessWidget {
  const DairyProducts({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: <Widget>[
          Card(
            img: "img/Arequipe.jpg",
            title: "Arequipe",
            about: "30Gr",
            price: 4000,
            press: () {
              arequipeModal(context);
            },
          ),
          Card(
            img: "img/Crema_de_leche.jpg",
            title: "Crema leche",
            about: "100 gr",
            price: 3000,
            press: () {
              cremadelecheModal(context);
            },
          ),
          Card(
            img: "img/Cuajada.jpg",
            title: "Cuajada",
            about: "32Gr",
            price: 4000,
            press: () {
              cuajadaModal(context);
            },
          ),
          Card(
            img: "img/Leche_cabra.jpg",
            title: "Leche Cabra",
            about: "1 Litro",
            price: 10000,
            press: () {
              lecheDeCabralModal(context);
            },
          ),
          Card(
            img: "img/Leche_condensada.jpg",
            title: "Lecherita",
            about: "100 gr",
            price: 5000,
            press: () {
              lecheritaModal(context);
            },
          ),
          Card(
            img: "img/Leche_vaca.jpg",
            title: "Leche Vaca",
            about: "1 litro",
            price: 3000,
            press: () {
              lechedevacaModal(context);
            },
          ),
          Card(
            img: "img/Mantequilla.jpg",
            title: "Matequilla",
            about: "32Gr",
            price: 5000,
            press: () {
              mantequillaModal(context);
            },
          ),
          Card(
            img: "img/Queso.jpg",
            title: "Queso",
            about: "1 Libra",
            price: 10000,
            press: () {
              quesoModal(context);
            },
          ),
          Card(
            img: "img/Yogurt_de_mora.jpg",
            title: "Yogurt Mora",
            about: "100 ml",
            price: 1500,
            press: () {
              yogurtdemoraModal(context);
            },
          ),
          Card(
            img: "img/Yogurt_griego.jpg",
            title: "Yogurt",
            about: "40 gr",
            price: 8000,
            press: () {
              yogurtModal(context);
            },
          ),
        ],
      ),
    );
  }
}

class AgricolaProducts extends StatelessWidget {
  const AgricolaProducts({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: <Widget>[
          Card(
            img: "img/Acelgas.jpg",
            title: "Acelgas",
            about: "20 gr",
            price: 2000,
            press: () {
              acelgasModal(context);
            },
          ),
          Card(
            img: "img/Aguacate.jpg",
            title: "Aguacate",
            about: "1 Paq x 5",
            price: 6000,
            press: () {
              aguacateModal(context);
            },
          ),
          Card(
            img: "img/Brocoli.jpg",
            title: "Brócoli",
            about: "1 libra",
            price: 2500,
            press: () {
              brocoliModal(context);
            },
          ),
          Card(
            img: "img/Granadilla.jpg",
            title: "Granadilla",
            about: "1 Libra",
            price: 3000,
            press: () {
              granadillaModal(context);
            },
          ),
          Card(
            img: "img/Lechuga.jpg",
            title: "Lechuga",
            about: "1 libra",
            price: 3000,
            press: () {
              lechugaModal(context);
            },
          ),
          Card(
            img: "img/Maracuya.jpg",
            title: "Maracuyá",
            about: "1 Libra",
            price: 2500,
            press: () {
              maracuyaModal(context);
            },
          ),
          Card(
            img: "img/Mora.jpg",
            title: "Mora",
            about: "1 Libra",
            price: 2500,
            press: () {
              moraModal(context);
            },
          ),
          Card(
            img: "img/Tomate.jpg",
            title: "Tomate",
            about: "1 Paq x 6",
            price: 2000,
            press: () {
              tomateModal(context);
            },
          ),
          Card(
            img: "img/Suculentas.jpg",
            title: "Suculentas",
            about: "1 Suculenta",
            price: 5000,
            press: () {
              suculentasModal(context);
            },
          ),
          Card(
            img: "img/Zanahorias.jpg",
            title: "Zanahoria",
            about: "1 libra",
            price: 2000,
            press: () {
              zanahoriaModal(context);
            },
          ),
        ],
      ),
    );
  }
}

class FeaturedProducts extends StatelessWidget {
  const FeaturedProducts({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          FeaturedCard(
            img: "img/Destacados_1.jpg",
            press: () {
              destacados1Modal(context);
            },
          ),
          FeaturedCard(
            img: "img/Destacados_2.jpg",
            press: () {
              destacados2Modal(context);
            },
          ),
        ],
      ),
    );
  }
}

class FeaturedCard extends StatelessWidget {
  const FeaturedCard({
    Key? key,
    required this.img,
    required this.press,
  }) : super(key: key);
  final String img;
  final VoidCallback press;

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return GestureDetector(
      onTap: press,
      child: Container(
        margin: const EdgeInsets.only(
          left: kDefaultPadding,
          top: kDefaultPadding / 2,
          bottom: kDefaultPadding / 2,
        ),
        width: size.width * 0.8,
        height: 185,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30),
          image: DecorationImage(
            image: AssetImage(img),
          ),
        ),
      ),
    );
  }
}

class RecomendProducts extends StatelessWidget {
  const RecomendProducts({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: <Widget>[
          Card(
            img: "img/Huevos_gallina.jpg",
            title: 'Huevos',
            about: "Tipo AA x 30",
            price: 12000,
            press: () {
              huevosAAModal(context);
            },
          ),
          Card(
            img: "img/Miel.jpg",
            title: 'Miel',
            about: "32gr x 1",
            price: 18000,
            press: () {
              mielModal(context);
            },
          ),
          Card(
            img: "img/Tomate.jpg",
            title: 'Tomate',
            about: "1 paq x 6",
            price: 2000,
            press: () {
              tomateModal(context);
            },
          ),
          Card(
            img: "img/Mora.jpg",
            title: 'Mora',
            about: "1 Libra",
            price: 2500,
            press: () {
              moraModal(context);
            },
          ),
          Card(
            img: "img/Leche_cabra.jpg",
            title: 'Leche Cabra',
            about: "1 litro",
            price: 10000,
            press: () {
              lecheDeCabralModal(context);
            },
          ),
        ],
      ),
    );
  }
}

class Card extends StatelessWidget {
  const Card({
    Key? key,
    required this.img,
    required this.title,
    required this.about,
    required this.price,
    required this.press,
  }) : super(key: key);

  final String img, title, about;
  final int price;
  final VoidCallback press;

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return SingleChildScrollView(
      child: Container(
        margin: const EdgeInsets.only(
          left: kDefaultPadding,
          top: kDefaultPadding / 2,
          bottom: kDefaultPadding * 2.5,
        ),
        width: size.width * 0.4,
        child: GestureDetector(
          onTap: press,
          child: Column(
            children: <Widget>[
              Image.asset(img),
              Container(
                padding: const EdgeInsets.all(kDefaultPadding / 2),
                decoration: BoxDecoration(
                  borderRadius: const BorderRadius.only(
                    bottomLeft: Radius.circular(10),
                    bottomRight: Radius.circular(10),
                  ),
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                      offset: const Offset(0, 10),
                      blurRadius: 50,
                      color: kPrimaryColor.withOpacity(0.23),
                    ),
                  ],
                ),
                child: Row(
                  children: <Widget>[
                    RichText(
                      text: TextSpan(
                        children: [
                          TextSpan(
                            text: "$title\n".toUpperCase(),
                            style: Theme.of(context).textTheme.button,
                          ),
                          TextSpan(
                            text: about.toUpperCase(),
                            style: TextStyle(
                              color: kPrimaryColor.withOpacity(0.5),
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Spacer(),
                    Text(
                      "\$$price",
                      style: Theme.of(context)
                          .textTheme
                          .button
                          ?.copyWith(color: kPrimaryColor, fontSize: 12),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}

class TitleWithSeeMore extends StatelessWidget {
  const TitleWithSeeMore({
    Key? key,
    required this.text,
    required this.press,
  }) : super(key: key);
  final String text;
  final VoidCallback press;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: kDefaultPadding + 10),
      child: Row(
        children: <Widget>[
          SizedBox(
            height: 24,
            child: Stack(
              children: <Widget>[
                Text(
                  text,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                  ),
                ),
              ],
            ),
          ),
          const Spacer(),
          ElevatedButton(
            style: ButtonStyle(
              shape: MaterialStateProperty.all(
                RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
            ),
            onPressed: press,
            child: const Text("Más info"),
          )
        ],
      ),
    );
  }
}

class HeaderWithSearchBox extends StatelessWidget {
  const HeaderWithSearchBox({
    Key? key,
    required this.size,
  }) : super(key: key);

  final Size size;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: kDefaultPadding * 2),
      height: size.height * 0.2 - 45,
      child: Stack(
        children: <Widget>[
          Container(
            height: size.height * 0.1 + 20,
            decoration: const BoxDecoration(
              color: kPrimaryColor,
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(40),
                bottomRight: Radius.circular(40),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text(
                  "¡Hola Usuario!",
                  style: Theme.of(context).textTheme.headline5?.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

categoriasModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 200,
            minHeight: 200,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Categorias",
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 20,
                            color: kBackgroundColor),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(
                          Boxicons.bx_x_circle,
                          color: kBackgroundColor,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "Categorias que tiene el Centro de Biotecnología Agropecuaria Sena en el momento disponibles",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

recomendadoModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 200,
            minHeight: 200,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Recomendado",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "Productos Recomendados del CBA para la venta, siendo estos los recomendados al publico",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

destacadosModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 200,
            minHeight: 200,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Destacados",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "Productos que fueron destacados en esta temporada por su Boom en nuestra comercializadora",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

agricolaModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 200,
            minHeight: 200,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Agricola",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "Productos Agricolas cultivados y cosechados por nuestros aprencides en el Centro de Biotecnología Agropecuaria SENA",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

lacteosModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 200,
            minHeight: 200,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Lacteos",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "Productos Lacteos hechos por nuestros aprendices para la comercializadora, siendo estos seguros y frescos.",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

productoAnimalModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 200,
            minHeight: 200,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Producto Animal",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "Productos provenientes y derivados de animales tratados de la mejor manera para su consumo en el Centro de Biotecnología Agropecuaria SENA",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

huevosAAModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 250,
            minHeight: 220,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Huevos Tamaño AA",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "Huevos de granja feliz cosechados por nuestros aprendices siento estos una fuente de proteina y calcio muy importante, se vende por cubeta",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding + 10,
                    bottom: kDefaultPadding - 10,
                  ),
                  child: Container(
                    padding: const EdgeInsets.only(
                      top: kDefaultPadding,
                    ),
                    margin: const EdgeInsets.symmetric(
                      horizontal: kDefaultPadding - 15,
                    ),
                    height: 2,
                    color: kBackgroundColor,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                    vertical: kDefaultPadding - 10,
                  ),
                  child: GestureDetector(
                    onTap: () {},
                    child: Row(
                      children: const <Widget>[
                        Text(
                          "Agregar a mi lista",
                          style: TextStyle(
                            color: kBackgroundColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Spacer(),
                        Icon(
                          Icons.receipt_long_rounded,
                          color: kBackgroundColor,
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      );
    },
  );
}

mielModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 250,
            minHeight: 200,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Miel",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "Miel cosechada y tratada por nuestros aprencides, la miel se comercializa en un frasco de vidirio como en la foto, pesando este 32 Gramos",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding + 10,
                    bottom: kDefaultPadding - 10,
                  ),
                  child: Container(
                    padding: const EdgeInsets.only(
                      top: kDefaultPadding,
                    ),
                    margin: const EdgeInsets.symmetric(
                      horizontal: kDefaultPadding - 15,
                    ),
                    height: 2,
                    color: kBackgroundColor,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                    vertical: kDefaultPadding - 10,
                  ),
                  child: GestureDetector(
                    onTap: () {},
                    child: Row(
                      children: const <Widget>[
                        Text(
                          "Agregar a mi lista",
                          style: TextStyle(
                            color: kBackgroundColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Spacer(),
                        Icon(
                          Icons.receipt_long_rounded,
                          color: kBackgroundColor,
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      );
    },
  );
}

tomateModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 270,
            minHeight: 200,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Tomate",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "Tomate cosechado por nuestros aprendices, este siendo una de las verduras más conocidas, se venden en un paquete de plasticos con 6 unidades cada paca",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding + 10,
                    bottom: kDefaultPadding - 10,
                  ),
                  child: Container(
                    padding: const EdgeInsets.only(
                      top: kDefaultPadding,
                    ),
                    margin: const EdgeInsets.symmetric(
                      horizontal: kDefaultPadding - 15,
                    ),
                    height: 2,
                    color: kBackgroundColor,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                    vertical: kDefaultPadding - 10,
                  ),
                  child: GestureDetector(
                    onTap: () {},
                    child: Row(
                      children: const <Widget>[
                        Text(
                          "Agregar a mi lista",
                          style: TextStyle(
                            color: kBackgroundColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Spacer(),
                        Icon(
                          Icons.receipt_long_rounded,
                          color: kBackgroundColor,
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      );
    },
  );
}

moraModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 250,
            minHeight: 200,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Mora",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "La mora es un excelente producto para acompañarlo en el almuerzo en forma de bebida, se vende en bolsas con la libra deseada",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding + 10,
                    bottom: kDefaultPadding - 10,
                  ),
                  child: Container(
                    padding: const EdgeInsets.only(
                      top: kDefaultPadding,
                    ),
                    margin: const EdgeInsets.symmetric(
                      horizontal: kDefaultPadding - 15,
                    ),
                    height: 2,
                    color: kBackgroundColor,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                    vertical: kDefaultPadding - 10,
                  ),
                  child: GestureDetector(
                    onTap: () {},
                    child: Row(
                      children: const <Widget>[
                        Text(
                          "Agregar a mi lista",
                          style: TextStyle(
                            color: kBackgroundColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Spacer(),
                        Icon(
                          Icons.receipt_long_rounded,
                          color: kBackgroundColor,
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      );
    },
  );
}

lecheDeCabralModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 250,
            minHeight: 200,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Leche de Cabra",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "La leche de cabra es una fuente muy grande de calcio, esta fue cosechada por nuestros aprendices, se vende por litro en una botella de vidrio",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding + 10,
                    bottom: kDefaultPadding - 10,
                  ),
                  child: Container(
                    padding: const EdgeInsets.only(
                      top: kDefaultPadding,
                    ),
                    margin: const EdgeInsets.symmetric(
                      horizontal: kDefaultPadding - 15,
                    ),
                    height: 2,
                    color: kBackgroundColor,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                    vertical: kDefaultPadding - 10,
                  ),
                  child: GestureDetector(
                    onTap: () {},
                    child: Row(
                      children: const <Widget>[
                        Text(
                          "Agregar a mi lista",
                          style: TextStyle(
                            color: kBackgroundColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Spacer(),
                        Icon(
                          Icons.receipt_long_rounded,
                          color: kBackgroundColor,
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      );
    },
  );
}

destacados1Modal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 200,
            minHeight: 200,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Tomate",
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 20,
                            color: kBackgroundColor),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(
                          Boxicons.bx_x_circle,
                          color: kBackgroundColor,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "El tomate en este periodo tuvo un aumento del 40% en las ventas siendo esto algo nuevo en nuestra comercializadora",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

destacados2Modal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 200,
            minHeight: 200,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Lechuga",
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 20,
                            color: kBackgroundColor),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(
                          Boxicons.bx_x_circle,
                          color: kBackgroundColor,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "La lechuga fue un producto que tuvo su boom por el aumento de demanda de este, siendo un 70% más demandado que otro producto en nuestra comercializadora",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

acelgasModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 260,
            minHeight: 220,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Acelgas",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "Las acelgas destacan por su altísimo valor nutricional y por ser unos vegetales que aportan un contenido calórico muy bajo a tu dieta, se vende por atao ",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding + 10,
                    bottom: kDefaultPadding - 10,
                  ),
                  child: Container(
                    padding: const EdgeInsets.only(
                      top: kDefaultPadding,
                    ),
                    margin: const EdgeInsets.symmetric(
                      horizontal: kDefaultPadding - 15,
                    ),
                    height: 2,
                    color: kBackgroundColor,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                    vertical: kDefaultPadding - 10,
                  ),
                  child: GestureDetector(
                    onTap: () {},
                    child: Row(
                      children: const <Widget>[
                        Text(
                          "Agregar a mi lista",
                          style: TextStyle(
                            color: kBackgroundColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Spacer(),
                        Icon(
                          Icons.receipt_long_rounded,
                          color: kBackgroundColor,
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      );
    },
  );
}

aguacateModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 250,
            minHeight: 220,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Aguacate",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "El aguacate Mejora la digestión. Nutre la piel, las uñas y el cabello por su alto contenido en vitaminas C y E, se vende en un paquete de 5 aguacates",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding + 10,
                    bottom: kDefaultPadding - 10,
                  ),
                  child: Container(
                    padding: const EdgeInsets.only(
                      top: kDefaultPadding,
                    ),
                    margin: const EdgeInsets.symmetric(
                      horizontal: kDefaultPadding - 15,
                    ),
                    height: 2,
                    color: kBackgroundColor,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                    vertical: kDefaultPadding - 10,
                  ),
                  child: GestureDetector(
                    onTap: () {},
                    child: Row(
                      children: const <Widget>[
                        Text(
                          "Agregar a mi lista",
                          style: TextStyle(
                            color: kBackgroundColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Spacer(),
                        Icon(
                          Icons.receipt_long_rounded,
                          color: kBackgroundColor,
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      );
    },
  );
}

brocoliModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 266,
            minHeight: 220,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Brócoli",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "El brócoli posee una mayor riqueza en vitaminas y minerales respecto al resto de las crucíferas. Se destaca su contenido en vitamina A, vitamina C, ácido fólico, potasio y hierro, Se vende por libra un paquete",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding + 10,
                    bottom: kDefaultPadding - 10,
                  ),
                  child: Container(
                    padding: const EdgeInsets.only(
                      top: kDefaultPadding,
                    ),
                    margin: const EdgeInsets.symmetric(
                      horizontal: kDefaultPadding - 15,
                    ),
                    height: 2,
                    color: kBackgroundColor,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                    vertical: kDefaultPadding - 10,
                  ),
                  child: GestureDetector(
                    onTap: () {},
                    child: Row(
                      children: const <Widget>[
                        Text(
                          "Agregar a mi lista",
                          style: TextStyle(
                            color: kBackgroundColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Spacer(),
                        Icon(
                          Icons.receipt_long_rounded,
                          color: kBackgroundColor,
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      );
    },
  );
}

granadillaModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 234,
            minHeight: 220,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Granadilla",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "La granadilla te puede ayudar a prevenir el estreñimiento, los malestares de la gastritis y la acidez, se vende por libras la granadilla",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding + 10,
                    bottom: kDefaultPadding - 10,
                  ),
                  child: Container(
                    padding: const EdgeInsets.only(
                      top: kDefaultPadding,
                    ),
                    margin: const EdgeInsets.symmetric(
                      horizontal: kDefaultPadding - 15,
                    ),
                    height: 2,
                    color: kBackgroundColor,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                    vertical: kDefaultPadding - 10,
                  ),
                  child: GestureDetector(
                    onTap: () {},
                    child: Row(
                      children: const <Widget>[
                        Text(
                          "Agregar a mi lista",
                          style: TextStyle(
                            color: kBackgroundColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Spacer(),
                        Icon(
                          Icons.receipt_long_rounded,
                          color: kBackgroundColor,
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      );
    },
  );
}

lechugaModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 250,
            minHeight: 220,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Lechuga",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "Los beneficios principales que te aporta la lechuga son: Es un alimento remineralizante, alcalinizante y refrescante, la lechuga se vende por ramo cada uno",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding + 10,
                    bottom: kDefaultPadding - 10,
                  ),
                  child: Container(
                    padding: const EdgeInsets.only(
                      top: kDefaultPadding,
                    ),
                    margin: const EdgeInsets.symmetric(
                      horizontal: kDefaultPadding - 15,
                    ),
                    height: 2,
                    color: kBackgroundColor,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                    vertical: kDefaultPadding - 10,
                  ),
                  child: GestureDetector(
                    onTap: () {},
                    child: Row(
                      children: const <Widget>[
                        Text(
                          "Agregar a mi lista",
                          style: TextStyle(
                            color: kBackgroundColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Spacer(),
                        Icon(
                          Icons.receipt_long_rounded,
                          color: kBackgroundColor,
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      );
    },
  );
}

maracuyaModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 218,
            minHeight: 218,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Maracuyá",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "La maracuyá es un fruto con gran aporte de vitamina C, potasio y calcio, esta se vende por paquetes de 1 libra",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding + 10,
                    bottom: kDefaultPadding - 10,
                  ),
                  child: Container(
                    padding: const EdgeInsets.only(
                      top: kDefaultPadding,
                    ),
                    margin: const EdgeInsets.symmetric(
                      horizontal: kDefaultPadding - 15,
                    ),
                    height: 2,
                    color: kBackgroundColor,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                    vertical: kDefaultPadding - 10,
                  ),
                  child: GestureDetector(
                    onTap: () {},
                    child: Row(
                      children: const <Widget>[
                        Text(
                          "Agregar a mi lista",
                          style: TextStyle(
                            color: kBackgroundColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Spacer(),
                        Icon(
                          Icons.receipt_long_rounded,
                          color: kBackgroundColor,
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      );
    },
  );
}

suculentasModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 266,
            minHeight: 220,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Suculentas",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "Las plantas suculentas o crasas son aquellas en las que algún órgano está especializado en el almacenamiento de agua en cantidades mayores que las plantas sin esta adaptación, esta se vende por unidad",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding + 10,
                    bottom: kDefaultPadding - 10,
                  ),
                  child: Container(
                    padding: const EdgeInsets.only(
                      top: kDefaultPadding,
                    ),
                    margin: const EdgeInsets.symmetric(
                      horizontal: kDefaultPadding - 15,
                    ),
                    height: 2,
                    color: kBackgroundColor,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                    vertical: kDefaultPadding - 10,
                  ),
                  child: GestureDetector(
                    onTap: () {},
                    child: Row(
                      children: const <Widget>[
                        Text(
                          "Agregar a mi lista",
                          style: TextStyle(
                            color: kBackgroundColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Spacer(),
                        Icon(
                          Icons.receipt_long_rounded,
                          color: kBackgroundColor,
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      );
    },
  );
}

zanahoriaModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 266,
            minHeight: 220,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Zanahoria",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "La Zanahoria Es rica en fósforo, el cual vigoriza las mentes y cuerpos cansados. Es muy útil para eliminar los cólicos y favorece la digestión, esta se vende en paquetes de 1 libra",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding + 10,
                    bottom: kDefaultPadding - 10,
                  ),
                  child: Container(
                    padding: const EdgeInsets.only(
                      top: kDefaultPadding,
                    ),
                    margin: const EdgeInsets.symmetric(
                      horizontal: kDefaultPadding - 15,
                    ),
                    height: 2,
                    color: kBackgroundColor,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                    vertical: kDefaultPadding - 10,
                  ),
                  child: GestureDetector(
                    onTap: () {},
                    child: Row(
                      children: const <Widget>[
                        Text(
                          "Agregar a mi lista",
                          style: TextStyle(
                            color: kBackgroundColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Spacer(),
                        Icon(
                          Icons.receipt_long_rounded,
                          color: kBackgroundColor,
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      );
    },
  );
}

arequipeModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 266,
            minHeight: 220,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Arequipe",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "El arequipe es un producto lácteo, producido por la cocción de leche con azúcar y que generalmente se utiliza como cobertura de postres o para untar o jaspear, se vende por frascos de 30gr",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding + 10,
                    bottom: kDefaultPadding - 10,
                  ),
                  child: Container(
                    padding: const EdgeInsets.only(
                      top: kDefaultPadding,
                    ),
                    margin: const EdgeInsets.symmetric(
                      horizontal: kDefaultPadding - 15,
                    ),
                    height: 2,
                    color: kBackgroundColor,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                    vertical: kDefaultPadding - 10,
                  ),
                  child: GestureDetector(
                    onTap: () {},
                    child: Row(
                      children: const <Widget>[
                        Text(
                          "Agregar a mi lista",
                          style: TextStyle(
                            color: kBackgroundColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Spacer(),
                        Icon(
                          Icons.receipt_long_rounded,
                          color: kBackgroundColor,
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      );
    },
  );
}

cremadelecheModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 250,
            minHeight: 220,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Crema de Leche",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "La crema, nata o gordura de leche es una sustancia de consistencia grasa y color marfil que se encuentra de forma emulsionada en la leche recién ordeñada o cruda, se vende por gramaje",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding + 10,
                    bottom: kDefaultPadding - 10,
                  ),
                  child: Container(
                    padding: const EdgeInsets.only(
                      top: kDefaultPadding,
                    ),
                    margin: const EdgeInsets.symmetric(
                      horizontal: kDefaultPadding - 15,
                    ),
                    height: 2,
                    color: kBackgroundColor,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                    vertical: kDefaultPadding - 10,
                  ),
                  child: GestureDetector(
                    onTap: () {},
                    child: Row(
                      children: const <Widget>[
                        Text(
                          "Agregar a mi lista",
                          style: TextStyle(
                            color: kBackgroundColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Spacer(),
                        Icon(
                          Icons.receipt_long_rounded,
                          color: kBackgroundColor,
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      );
    },
  );
}

cuajadaModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 320,
            minHeight: 320,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Cuajada",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "La Cuajada no se trata de un queso como tal, sino de leche coagulada sin fermentar con cuajo animal o bien extracto de cardo. Podemos encontrar dos variedades diferentes, la Cuajada que se elabora sin apenas nata ni suero, conocida como Cuajada natural, o la obtenida por coagulación, se vende por libra",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding + 10,
                    bottom: kDefaultPadding - 10,
                  ),
                  child: Container(
                    padding: const EdgeInsets.only(
                      top: kDefaultPadding,
                    ),
                    margin: const EdgeInsets.symmetric(
                      horizontal: kDefaultPadding - 15,
                    ),
                    height: 2,
                    color: kBackgroundColor,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                    vertical: kDefaultPadding - 10,
                  ),
                  child: GestureDetector(
                    onTap: () {},
                    child: Row(
                      children: const <Widget>[
                        Text(
                          "Agregar a mi lista",
                          style: TextStyle(
                            color: kBackgroundColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Spacer(),
                        Icon(
                          Icons.receipt_long_rounded,
                          color: kBackgroundColor,
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      );
    },
  );
}

lechedevacaModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 266,
            minHeight: 266,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Leche de vaca",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "La leche de vaca cruda es un líquido de color blanco amarillento que ha adquirido gran importancia en la alimentación humana. Al hablar de leche se entiende única y exclusivamente la natural de vaca, se vende por litro",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding + 10,
                    bottom: kDefaultPadding - 10,
                  ),
                  child: Container(
                    padding: const EdgeInsets.only(
                      top: kDefaultPadding,
                    ),
                    margin: const EdgeInsets.symmetric(
                      horizontal: kDefaultPadding - 15,
                    ),
                    height: 2,
                    color: kBackgroundColor,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                    vertical: kDefaultPadding - 10,
                  ),
                  child: GestureDetector(
                    onTap: () {},
                    child: Row(
                      children: const <Widget>[
                        Text(
                          "Agregar a mi lista",
                          style: TextStyle(
                            color: kBackgroundColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Spacer(),
                        Icon(
                          Icons.receipt_long_rounded,
                          color: kBackgroundColor,
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      );
    },
  );
}

lecheritaModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 300,
            minHeight: 300,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Leche condensada",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "La leche condensada se obtiene eliminando parte del agua que contiene la leche de partida y añadiendo azúcar. También se somete a un tratamiento térmico, con el fin de garantizar la estabilidad del alimento a temperatura ambiente, mientras el envase esté cerrado, se vende por gramaje",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding + 10,
                    bottom: kDefaultPadding - 10,
                  ),
                  child: Container(
                    padding: const EdgeInsets.only(
                      top: kDefaultPadding,
                    ),
                    margin: const EdgeInsets.symmetric(
                      horizontal: kDefaultPadding - 15,
                    ),
                    height: 2,
                    color: kBackgroundColor,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                    vertical: kDefaultPadding - 10,
                  ),
                  child: GestureDetector(
                    onTap: () {},
                    child: Row(
                      children: const <Widget>[
                        Text(
                          "Agregar a mi lista",
                          style: TextStyle(
                            color: kBackgroundColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Spacer(),
                        Icon(
                          Icons.receipt_long_rounded,
                          color: kBackgroundColor,
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      );
    },
  );
}

mantequillaModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 282,
            minHeight: 282,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Mantequilla",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "La mantequilla es un derivado lácteo con un elevado contenido graso, derivado exclusivamente de la leche o de determinados productos lácteos, en forma de emulsión sólida principalmente del tipo agua en materia grasa, se vende por libra cuarto y medias",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding + 10,
                    bottom: kDefaultPadding - 10,
                  ),
                  child: Container(
                    padding: const EdgeInsets.only(
                      top: kDefaultPadding,
                    ),
                    margin: const EdgeInsets.symmetric(
                      horizontal: kDefaultPadding - 15,
                    ),
                    height: 2,
                    color: kBackgroundColor,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                    vertical: kDefaultPadding - 10,
                  ),
                  child: GestureDetector(
                    onTap: () {},
                    child: Row(
                      children: const <Widget>[
                        Text(
                          "Agregar a mi lista",
                          style: TextStyle(
                            color: kBackgroundColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Spacer(),
                        Icon(
                          Icons.receipt_long_rounded,
                          color: kBackgroundColor,
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      );
    },
  );
}

quesoModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 300,
            minHeight: 300,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Queso",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "El queso es un alimento elaborado a partir de la leche cuajada de vaca, cabra, oveja u otros mamíferos. Sus diferentes estilos y sabores son el resultado del uso de distintas especies de bacterias y mohos, niveles de nata en la leche, curación, tratamientos en su proceso, etc, se vende por libra",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding + 10,
                    bottom: kDefaultPadding - 10,
                  ),
                  child: Container(
                    padding: const EdgeInsets.only(
                      top: kDefaultPadding,
                    ),
                    margin: const EdgeInsets.symmetric(
                      horizontal: kDefaultPadding - 15,
                    ),
                    height: 2,
                    color: kBackgroundColor,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                    vertical: kDefaultPadding - 10,
                  ),
                  child: GestureDetector(
                    onTap: () {},
                    child: Row(
                      children: const <Widget>[
                        Text(
                          "Agregar a mi lista",
                          style: TextStyle(
                            color: kBackgroundColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Spacer(),
                        Icon(
                          Icons.receipt_long_rounded,
                          color: kBackgroundColor,
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      );
    },
  );
}

yogurtdemoraModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 320,
            minHeight: 320,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Yogurt de Mora",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "Es un producto lácteo obtenido mediante la fermentación de la leche3 por medio de bacterias de los géneros Lactobacillus y Streptococcus. Se suelen usar varias cepas diferentes para conseguir una fermentación más completa, existen varios sabores de yogurt, pero el más producido es el de mora, se vende por mililitros y litros",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding + 10,
                    bottom: kDefaultPadding - 10,
                  ),
                  child: Container(
                    padding: const EdgeInsets.only(
                      top: kDefaultPadding,
                    ),
                    margin: const EdgeInsets.symmetric(
                      horizontal: kDefaultPadding - 15,
                    ),
                    height: 2,
                    color: kBackgroundColor,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                    vertical: kDefaultPadding - 10,
                  ),
                  child: GestureDetector(
                    onTap: () {},
                    child: Row(
                      children: const <Widget>[
                        Text(
                          "Agregar a mi lista",
                          style: TextStyle(
                            color: kBackgroundColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Spacer(),
                        Icon(
                          Icons.receipt_long_rounded,
                          color: kBackgroundColor,
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      );
    },
  );
}

yogurtModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 290,
            minHeight: 290,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Yogurt Griego",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "El yogur griego, también llamado labne, es el yogur que se cola para retirar el suero de leche, generando en una textura mucho más espesa y cremosa que la del yogur natural, manteniendo ese amargor característico y sumándole notas cítricas, se vende por gramaje",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding + 10,
                    bottom: kDefaultPadding - 10,
                  ),
                  child: Container(
                    padding: const EdgeInsets.only(
                      top: kDefaultPadding,
                    ),
                    margin: const EdgeInsets.symmetric(
                      horizontal: kDefaultPadding - 15,
                    ),
                    height: 2,
                    color: kBackgroundColor,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                    vertical: kDefaultPadding - 10,
                  ),
                  child: GestureDetector(
                    onTap: () {},
                    child: Row(
                      children: const <Widget>[
                        Text(
                          "Agregar a mi lista",
                          style: TextStyle(
                            color: kBackgroundColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Spacer(),
                        Icon(
                          Icons.receipt_long_rounded,
                          color: kBackgroundColor,
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      );
    },
  );
}

huevosdecodornizModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 320,
            minHeight: 320,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Huevos de Codorniz",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "Más pequeños que los de gallina y con una yema más viva, los huevos de codorniz son una auténtica exquisitez que destaca por su alto contenido en proteínas y la casi inexistencia de carbohidratos. De hecho, su aporte energético es superior a los primeros pese a sus dimensiones inferiores, se vende por cubeta x 6",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding + 10,
                    bottom: kDefaultPadding - 10,
                  ),
                  child: Container(
                    padding: const EdgeInsets.only(
                      top: kDefaultPadding,
                    ),
                    margin: const EdgeInsets.symmetric(
                      horizontal: kDefaultPadding - 15,
                    ),
                    height: 2,
                    color: kBackgroundColor,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                    vertical: kDefaultPadding - 10,
                  ),
                  child: GestureDetector(
                    onTap: () {},
                    child: Row(
                      children: const <Widget>[
                        Text(
                          "Agregar a mi lista",
                          style: TextStyle(
                            color: kBackgroundColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Spacer(),
                        Icon(
                          Icons.receipt_long_rounded,
                          color: kBackgroundColor,
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      );
    },
  );
}

huevosAModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 250,
            minHeight: 220,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Huevos Tamaño A",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "Huevos de granja feliz cosechados por nuestros aprendices siento estos una fuente de proteina y calcio muy importante, se vende por cubeta",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding + 10,
                    bottom: kDefaultPadding - 10,
                  ),
                  child: Container(
                    padding: const EdgeInsets.only(
                      top: kDefaultPadding,
                    ),
                    margin: const EdgeInsets.symmetric(
                      horizontal: kDefaultPadding - 15,
                    ),
                    height: 2,
                    color: kBackgroundColor,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                    vertical: kDefaultPadding - 10,
                  ),
                  child: GestureDetector(
                    onTap: () {},
                    child: Row(
                      children: const <Widget>[
                        Text(
                          "Agregar a mi lista",
                          style: TextStyle(
                            color: kBackgroundColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Spacer(),
                        Icon(
                          Icons.receipt_long_rounded,
                          color: kBackgroundColor,
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      );
    },
  );
}

huevosAAAModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 250,
            minHeight: 220,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Huevos Tamaño AAA",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "Huevos de granja feliz cosechados por nuestros aprendices siento estos una fuente de proteina y calcio muy importante, se vende por cubeta",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding + 10,
                    bottom: kDefaultPadding - 10,
                  ),
                  child: Container(
                    padding: const EdgeInsets.only(
                      top: kDefaultPadding,
                    ),
                    margin: const EdgeInsets.symmetric(
                      horizontal: kDefaultPadding - 15,
                    ),
                    height: 2,
                    color: kBackgroundColor,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                    vertical: kDefaultPadding - 10,
                  ),
                  child: GestureDetector(
                    onTap: () {},
                    child: Row(
                      children: const <Widget>[
                        Text(
                          "Agregar a mi lista",
                          style: TextStyle(
                            color: kBackgroundColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Spacer(),
                        Icon(
                          Icons.receipt_long_rounded,
                          color: kBackgroundColor,
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      );
    },
  );
}

huevosjumboModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 250,
            minHeight: 220,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Huevos Tamaño Jumbo",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "Huevos de granja feliz cosechados por nuestros aprendices siento estos una fuente de proteina y calcio muy importante, se vende por cubeta",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding + 10,
                    bottom: kDefaultPadding - 10,
                  ),
                  child: Container(
                    padding: const EdgeInsets.only(
                      top: kDefaultPadding,
                    ),
                    margin: const EdgeInsets.symmetric(
                      horizontal: kDefaultPadding - 15,
                    ),
                    height: 2,
                    color: kBackgroundColor,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                    vertical: kDefaultPadding - 10,
                  ),
                  child: GestureDetector(
                    onTap: () {},
                    child: Row(
                      children: const <Widget>[
                        Text(
                          "Agregar a mi lista",
                          style: TextStyle(
                            color: kBackgroundColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Spacer(),
                        Icon(
                          Icons.receipt_long_rounded,
                          color: kBackgroundColor,
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      );
    },
  );
}

polloModal(context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: kPrimaryColor,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
        child: Container(
          constraints: const BoxConstraints(
            maxHeight: 285,
            minHeight: 285,
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      const Text(
                        "Pollo",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: kBackgroundColor,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Boxicons.bx_x_circle),
                        color: kBackgroundColor,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding - 10,
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 15,
                  ),
                  height: 2,
                  color: kBackgroundColor,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.only(
                      top: kDefaultPadding - 10,
                    ),
                    child: Text(
                      "La carne de pollo está considerada como un alimento básico en la dieta humana. Su bajo costo de producción en comparación a otras carnes hace que sea consumida en casi todo el mundo y por todas las clases sociales, se vende por unidad",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: kBackgroundColor,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    top: kDefaultPadding + 10,
                    bottom: kDefaultPadding - 10,
                  ),
                  child: Container(
                    padding: const EdgeInsets.only(
                      top: kDefaultPadding,
                    ),
                    margin: const EdgeInsets.symmetric(
                      horizontal: kDefaultPadding - 15,
                    ),
                    height: 2,
                    color: kBackgroundColor,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: kDefaultPadding - 10,
                    vertical: kDefaultPadding - 10,
                  ),
                  child: GestureDetector(
                    onTap: () {},
                    child: Row(
                      children: const <Widget>[
                        Text(
                          "Agregar a mi lista",
                          style: TextStyle(
                            color: kBackgroundColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Spacer(),
                        Icon(
                          Icons.receipt_long_rounded,
                          color: kBackgroundColor,
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      );
    },
  );
}
