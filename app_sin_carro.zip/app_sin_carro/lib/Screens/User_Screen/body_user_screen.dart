import 'package:boxicons/boxicons.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../../constants.dart';

class BodyUserScreen extends StatefulWidget {
  const BodyUserScreen({
    Key? key,
  }) : super(key: key);

  @override
  State<BodyUserScreen> createState() => _BodyUserScreenState();
}

class _BodyUserScreenState extends State<BodyUserScreen> {
  final user = FirebaseAuth.instance.currentUser!;
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Column(
      children: <Widget>[
        Container(
          height: size.height * 0.1,
          decoration: const BoxDecoration(
            color: kPrimaryColor,
            borderRadius: BorderRadius.only(
              bottomLeft: Radius.circular(40),
              bottomRight: Radius.circular(40),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(top: kDefaultPadding),
          child: Column(
            children: <Widget>[
              const Icon(
                Icons.person,
                size: 100,
              ),
              Padding(
                padding: const EdgeInsets.only(top: kDefaultPadding),
                child: Text(
                  "¡Hola ${user.email!}!",
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              )
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(
            top: kDefaultPadding * 6,
          ),
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: kDefaultPadding * 2),
            child: Column(
              children: <Widget>[
                const Text(
                  "Correo",
                  style: TextStyle(
                    color: kPrimaryColor,
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: kDefaultPadding),
                  child: Column(
                    children: [
                      Text(
                        user.email!,
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(
            top: kDefaultPadding + 10,
            right: kDefaultPadding * 2,
          ),
          child: GestureDetector(
            onTap: () {
              FirebaseAuth.instance.signOut();
            },
            child: Padding(
              padding: const EdgeInsets.only(top: kDefaultPadding * 11),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: const <Widget>[
                  Padding(
                    padding: EdgeInsets.only(
                      left: kDefaultPadding * 2,
                    ),
                    child: Text(
                      "Al Salir de sesión deberas darle click en atras",
                      style: TextStyle(
                        fontSize: 10,
                      ),
                    ),
                  ),
                  Spacer(),
                  Text(
                    "Salir",
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Icon(
                    Boxicons.bx_log_out,
                    size: 30,
                  )
                ],
              ),
            ),
          ),
        )
      ],
    );
  }
}
